﻿namespace DotLiquid
{
    public interface IValueTypeConvertible
    {
        object ConvertToValueType();
    }
}
