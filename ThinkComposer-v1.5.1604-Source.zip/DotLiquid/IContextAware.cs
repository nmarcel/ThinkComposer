﻿namespace DotLiquid
{
	public interface IContextAware
	{
		Context Context { set; }
	}
}